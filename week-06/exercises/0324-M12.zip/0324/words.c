#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    while (1) {
        char line[51];
        gets(line);
        if(strlen(line) == 0) {
            break;
        }
        int count = 0;
        for(int i=0; i<strlen(line); i++) {
            if(line[i] == ' ') {
                count++;
            }
        }
        printf("%d\n", count + 1);
    }

    return EXIT_SUCCESS;
}