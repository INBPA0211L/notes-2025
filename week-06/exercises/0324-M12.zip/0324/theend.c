#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    while (1) {
        char line[21];
        gets(line);
        if(strcmp(line, "THE END") == 0) {
            break;
        }

        /*
        int count = 0;
        for(int i=0; i<strlen(line); i++) {
            if(line[i] == ' ') {
                count++;
            }
        }
        */

        if(strchr(line, ' ') == NULL && strlen(line) >= 10) {
            puts(line);
        }
    }

    return EXIT_SUCCESS;
}