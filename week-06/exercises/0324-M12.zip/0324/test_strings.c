#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void dump_string(char *line, int length) {
    for(int i=0; i<length; i++) {
        printf("%d *%c* %d %p\n",
            i, line[i], line[i], &line[i]
        );
    }
}

int main() {
    char line[51];

    gets(line);
    puts(line);
    dump_string(line, 15);

    puts(line + 3);
    printf("%d %d\n", strlen(line), sizeof(line));

    gets(line);
    puts(line);
    dump_string(line, 15);

    // line = "banana"; // = == !=
    strcpy(line, "banana");
    puts(line);
    strcpy(line + 6, " tree");
    puts(line);
    strcat(line, "xyz");
    puts(line);

    puts("===");
    char line2[51];
    gets(line);
    gets(line2);
    printf("%d\n", strcmp(line, line2));

    return EXIT_SUCCESS;
}