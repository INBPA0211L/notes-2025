#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    while (1)
    {
        char line[101];
        gets(line);

        if (strlen(line) &&
            strchr(".!?", line[strlen(line) - 1]))
        {
            puts(line);
        }

        /*
        if (strlen(line) >= 3 &&
            line[strlen(line) - 1] == '!' &&
            line[strlen(line) - 2] == '!' &&
            line[strlen(line) - 3] == '!')
        {
            break;
        }
            */

        char *p = line + strlen(line) - 3;
        if(strlen(line) >= 3 && strcmp(p, "!!!") == 0) {
            break;
        }
    }

    return EXIT_SUCCESS;
}